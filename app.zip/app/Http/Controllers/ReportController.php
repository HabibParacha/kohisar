<?php

namespace App\Http\Controllers;
use DB;
use PDF;

use URL;
use File;
use Excel;
use Image;
use Session;
use DateTime;
// for excel export
use Carbon\Carbon;
use App\Mail\SendMail;
// end for excel export
use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Yajra\DataTables\DataTables;
use App\Exports\SupplierLedgerExcel;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Crypt;
use PhpOffice\PhpSpreadsheet\Writer\Xls;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ReportController extends Controller
{
   
    public function fetchRawMaterailStock()
    {
        $data = DB::table('v_raw_material_stock_report')->get();

        return view('reports.raw_material_stock', compact('data'));

        
        
    }

    public function fetchFinishedGoodsStock()
    {
        $data = DB::table('v_finished_goods_stock_report')->get();

        return view('reports.finished_goods_stock', compact('data'));

    }
}
