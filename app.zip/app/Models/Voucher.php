<?php

namespace App\Models;

use App\Models\VoucherDetail;
use App\Models\ChartOfAccount;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Voucher extends Model
{
    use HasFactory;
    protected $fillable = [
        'voucher_no',
        'date',
        'code',
        'type',
        'chart_of_account_id',
        'narration',
        'total_amount',
        'attachment',
        'created_by',
    ];


    public function details()
    {
        return $this->hasMany(VoucherDetail::class);
    }
    public function chartOfAccount(){
        return $this->belongsTo(ChartOfAccount::class);
    }

    public static function generateVoucherNo($code){
        
        $max_vouhcer_no = DB::table('vouchers')
        ->where('code',$code)
        ->max('voucher_no');
        
        
        //if record exist
        if($max_vouhcer_no)
        {
            // Split by '-' and get the second part (the numeric part) +1
            $get_voucher_no_digits = (int)  explode('-', $max_vouhcer_no)[1] + 1;

            $voucher_no =  $code.'-'.$get_voucher_no_digits;

            return $voucher_no;
        }
        else{ 
            $voucher_no = $code.'-'.'1';
            return $voucher_no;// first invoice no
        }  
    }
}
