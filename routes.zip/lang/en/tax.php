<?php

return [
    'name' => 'VAT',
];
