$(document).ready(function () {
    alert("Yes");
    console.log("index.js is loaded successfully!");

});